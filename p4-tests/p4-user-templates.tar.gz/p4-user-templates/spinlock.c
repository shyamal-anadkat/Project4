
#include "types.h"
#include "user.h"

void spin_init(struct spinlock* lk)
{
	/* fill this in! */
}

void spin_lock(struct spinlock *lk)
{
	/* fill this in! */
}

void spin_unlock(struct spinlock *lk)
{
	/* fill this in! */
}
