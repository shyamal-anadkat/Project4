
#include "types.h"
#include "user.h"

void mutex_init(struct mutex* mtx)
{
	/* fill this in! */
}

void mutex_lock(struct mutex* mtx)
{
	/* fill this in! */
}

void mutex_unlock(struct mutex* mtx)
{
	/* fill this in! */
}
