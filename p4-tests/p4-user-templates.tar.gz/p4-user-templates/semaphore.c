
#include "types.h"
#include "user.h"

void sem_init(struct semaphore* sem, int initval)
{
	/* fill this in! */
}

void sem_wait(struct semaphore* sem)
{
	/* fill this in! */
}

void sem_post(struct semaphore* sem)
{
	/* fill this in! */
}

