
#include "types.h"
#include "user.h"

int thread_create(void (*thfunc)(void*), void* arg)
{
	/* fill this in! */
}

int thread_join(void)
{
	/* fill this in! */
}
