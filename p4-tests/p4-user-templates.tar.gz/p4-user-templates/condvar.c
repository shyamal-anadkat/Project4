
#include "types.h"
#include "user.h"

void cv_init(struct condvar* cv)
{
	/* fill this in! */
}

void cv_wait(struct condvar* cv, struct mutex* mtx)
{
	/* fill this in! */
}

void cv_signal(struct condvar* cv)
{
	/* fill this in! */
}

void cv_broadcast(struct condvar* cv)
{
	/* fill this in! */
}
